MARS24

INTRODUCTION

Mars24 is a cross-platform Java application that displays a Mars "sunclock",
a graphical representation of Mars showing the current sun- and nightsides
of Mars, along with a numerical readout of the time in a 24-hour format.
Other displays include a plot showing the relative orbital positions of Mars
and Earth and a diagram tracing the path of the Sun during the day.

Mars24 _requires_ that Java 8 (or later version) be installed on your computer.


DOWNLOADING

The current version of Mars24 may be found at:

  https://www.giss.nasa.gov/tools/mars24/


INSTALLING AND RUNNING THE STANDARD JAVA PACKAGE

The "standard" Mars24 package comes as either a (a) zipped archive or (b)
tarred and gzipped archive, either of which can be uncompressed by many
freeware uncompression utilities. It contains a directory, "Mars24J" which
holds the following items:

- Mars24 launcher in a shell command file called "mars24.sh".
- Application code files in a folder (sub-directory) called "jars".
- Martian landmarks file "marslandmarks.xml".
- This README file.

On most platforms, you may be able to launch Mars24 by double-clicking on the
Mars24.jar icon on the desktop. However, doing so means that Mars24 may not be
allocated enough memory when it is started, in which case it will likely not
work correctly.

Instead, you should run Mars24 from the shell command line; 'cd' into the
directory where the above files are located and then type:

./mars24.sh

This should execute a command in the shell file which starts Mars24 and
requests that it be allocated 2 GB of memory. You can increase the memory
allocation by editing the panoply.sh file and increasing the value specified
in the -Xmx option.

if neither of the above succeeds, you may try launching Mars24 directly
via command-line call, e.g., the following

java -jar -Xmx2000M Mars24.jar


JAR FILES

The sub-directory called jars _must_ remain in the same directory as the
panoply.sh script, and all the "jar" files it holds must remain in the jars
sub-directory. These files contain the Panoply application code and (re)moving
any of them will break Panoply.


HELP AND OTHER DOCUMENTATION

More details about Mars24, including a user's guide and information about
the meaning of Mars time units, are available at:

  https://www.giss.nasa.gov/tools/mars24/


REFERENCE

Mars24 is primarily based on equations that appeared in:

+ Allison and McEwen 2000. A post-Pathfinder evaluation of aerocentric solar
coordinates with improved timing recipes for Mars seasonal/diurnal climate
studies. Planet. Space Sci. 48, 215-235.

See "Technical Notes about Mars Time" in the help documents for additional
references and for discussion of corrections and updates to the algorithm
explained in the above paper.


CONTACT

Mars24 was written by Dr. Robert B. Schmunk. Please send queries and bug
reports about Mars24 to

Robert B. Schmunk
Robert.B.Schmunk@nasa.gov
NASA Goddard Institute for Space Studies
2880 Broadway, New York, NY 10025 USA

The definition of Mars Solar Time and the mathematical algorithms adopted
for its calculation by Mars24 were originally determined by Dr. Michael D.
Allison, then at the NASA Goddard Institute for Space Studies.


ACKNOWLEDGMENTS

Credit and acknowledgments for help with Mars timekeeping, Mars map images,
and Java code libraries are given in the Ackowledgments of the application
help windows.
