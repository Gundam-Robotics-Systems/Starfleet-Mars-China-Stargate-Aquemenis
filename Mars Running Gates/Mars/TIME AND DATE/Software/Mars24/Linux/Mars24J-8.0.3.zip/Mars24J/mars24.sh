#!/bin/sh
#

SCRIPTDIR=`dirname $SCRIPT`

java -Xms512m -Xmx2000m -jar $SCRIPTDIR/jars/Mars24.jar

