MARS24

INTRODUCTION

Mars24 is a cross-platform Java application that displays a Mars "sunclock",
a graphical representation of Mars showing the current sun- and nightsides
of Mars, along with a numerical readout of the time in a 24-hour format.
Other displays include a plot showing the relative orbital positions of Mars
and Earth and a diagram tracing the path of the Sun during the day.

Mars24 _requires_ that Java 8 (or later version) be installed on your computer.


DOWNLOADING

The current version of Mars24 may be found at:

  https://www.giss.nasa.gov/tools/mars24/


INSTALLING AND RUNNING THE WINDOWS PACKAGE

The Mars24 package for Windows comes as zipped archive. It contains
a directory, Mars24Win, which holds the following items:

- Mars24.exe application.
- "jars" folder containing several *.jar code files.
- Martian landmarks file "marslandmarks.xml".
- This README file.

To run Mars24, double-click on the Mars24.exe application icon.

If nothing happens when you double-click on Mars.exe, or if you see an error
dialog with no message, then you may not have a complete Java Runtime Engine
installed on your computer.


HELP AND OTHER DOCUMENTATION

More details about Mars24, including a user's guide and information about
the meaning of Mars time units, are available at:

  https://www.giss.nasa.gov/tools/mars24/


REFERENCE

Mars24 is primarily based on equations that appeared in:

+ Allison and McEwen 2000. A post-Pathfinder evaluation of aerocentric solar
coordinates with improved timing recipes for Mars seasonal/diurnal climate
studies. Planet. Space Sci. 48, 215-235.

See "Technical Notes about Mars Time" in the help documents for additional
references and for discussion of corrections and updates to the algorithm
explained in the above paper.


CONTACT

Mars24 was written by Dr. Robert B. Schmunk. Please send queries and bug
reports about Mars24 to

Robert B. Schmunk
Robert.B.Schmunk@nasa.gov
NASA Goddard Institute for Space Studies
2880 Broadway, New York, NY 10025 USA

The definition of Mars Solar Time and the mathematical algorithms adopted
for its calculation by Mars24 were originally determined by Dr. Michael D.
Allison, then at the NASA Goddard Institute for Space Studies.


ACKNOWLEDGMENTS

Credit and acknowledgments for help with Mars timekeeping, Mars map images,
and Java code libraries are given in the Ackowledgments of the application
help windows.
